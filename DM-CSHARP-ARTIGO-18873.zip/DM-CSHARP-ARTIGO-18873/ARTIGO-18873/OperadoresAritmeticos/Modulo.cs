namespace ARTIGO_18873.OperadoresAritmeticos
{
    public class Modulo
    {
        
    }
}